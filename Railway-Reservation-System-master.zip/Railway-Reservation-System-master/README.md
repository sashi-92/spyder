# Railway-Reservation-System

### Course project for Database Management Systems.
In this group project, we have developed a railway management system using **MySQL database**. Designed an ER model and translated the model to the relational schema for management of the railway system and created a website using PHP.

Tech Stack: PHP, HTML, CSS, Javascript

Database: MySQL
